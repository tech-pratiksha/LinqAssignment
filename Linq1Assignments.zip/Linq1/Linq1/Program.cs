﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Linq1
{
    class Employee
    {
        public int EmployeeID { get; set; }
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public string Title { get; set; }
        public DateTime DOB { get; set; }
        public DateTime DOJ { get; set; }
        public string City { get; set; }
    }
    class Program
    {
        public static List<Employee> empList = new List<Employee>
        {
            //new Employee() {EmployeeID = 1001,FirstName = "Malcolm",LastName = "Daruwalla",Title = "Manager",DOB = DateTime.Parse("1984-01-02"),DOJ = DateTime.Parse("2011-08-09"),City = "Mumbai"},
            //new Employee() {EmployeeID = 1002,FirstName = "Asdin",LastName = "Dhalla",Title = "AsstManager",DOB = DateTime.Parse("1984-08-20"),DOJ = DateTime.Parse("2012-7-7"),City = "Mumbai"},
            //new Employee() {EmployeeID = 1003,FirstName = "Madhavi",LastName = "Oza",Title = "Consultant",DOB = DateTime.Parse("1987/11/14"),DOJ = DateTime.Parse("2015/4/12"),City = "Pune"},
            //new Employee() {EmployeeID = 1004,FirstName = "Saba",LastName = "Shaikh",Title = "SE",DOB = DateTime.Parse("1990/6/3"),DOJ = DateTime.Parse("2016/2/2"),City = "Pune"},
            //new Employee() {EmployeeID = 1005,FirstName = "Nazia",LastName = "Shaikh",Title = "SE",DOB = DateTime.Parse("1991/3/8"),DOJ = DateTime.Parse("2016/2/2"),City = "Mumbai"},
            //new Employee() {EmployeeID = 1006,FirstName = "Suresh",LastName = "Pathak",Title = "Consultant",DOB = DateTime.Parse("1998/11/7"),DOJ = DateTime.Parse("2014/8/8"),City = "Chennai"},
            //new Employee() {EmployeeID = 1007,FirstName = "Vijay",LastName = "Natrajan",Title = "Consultant",DOB = DateTime.Parse("1989/12/2"),DOJ = DateTime.Parse("2015/6/1"),City = "Mumbai"},
            //new Employee() {EmployeeID = 1008,FirstName = "Rahul",LastName = "Dubey",Title = "Associate",DOB = DateTime.Parse("1993/11/11"),DOJ = DateTime.Parse("2014/11/6"),City = "Chennai"},
            //new Employee() {EmployeeID = 1009,FirstName = "Amit",LastName = "Mistry",Title = "Associate",DOB = DateTime.Parse("1992/8/12"),DOJ = DateTime.Parse("2014/12/3"),City = "Chennai"},
            //new Employee() {EmployeeID = 1010,FirstName = "Sumit",LastName = "Shah",Title = "Manager",DOB = DateTime.Parse("1991/4/12"),DOJ = DateTime.Parse("2016/1/2"),City = "Pune"},

            new Employee() {EmployeeID = 1001,FirstName = "Malcolm",LastName = "Daruwalla",Title = "Manager",DOB = DateTime.Parse("1984-01-02"),DOJ = DateTime.Parse("2011-08-09"),City = "Mumbai"},
            new Employee() {EmployeeID = 1002,FirstName = "Asdin",LastName = "Dhalla",Title = "AsstManager",DOB = DateTime.Parse("1984-08-20"),DOJ = DateTime.Parse("2012-7-7"),City = "Mumbai"},
            new Employee() {EmployeeID = 1003,FirstName = "Madhavi",LastName = "Oza",Title = "Consultant",DOB = DateTime.Parse("1987-11-14"),DOJ = DateTime.Parse("2015-4-12"),City = "Pune"},
            new Employee() {EmployeeID = 1004,FirstName = "Saba",LastName = "Shaikh",Title = "SE",DOB = DateTime.Parse("6/3/1990"),DOJ = DateTime.Parse("2/2/2016"),City = "Pune"},
            new Employee() {EmployeeID = 1005,FirstName = "Nazia",LastName = "Shaikh",Title = "SE",DOB = DateTime.Parse("3/8/1991"),DOJ = DateTime.Parse("2/2/2016"),City = "Mumbai"},
            new Employee() {EmployeeID = 1006,FirstName = "Suresh",LastName = "Pathak",Title = "Consultant",DOB = DateTime.Parse("11/7/1989"),DOJ = DateTime.Parse("8/8/2014"),City = "Chennai"},
            new Employee() {EmployeeID = 1007,FirstName = "Vijay",LastName = "Natrajan",Title = "Consultant",DOB = DateTime.Parse("12/2/1989"),DOJ = DateTime.Parse("6/1/2015"),City = "Mumbai"},
            new Employee() {EmployeeID = 1008,FirstName = "Rahul",LastName = "Dubey",Title = "Associate",DOB = DateTime.Parse("11/11/1993"),DOJ = DateTime.Parse("11/6/2014"),City = "Chennai"},
            new Employee() {EmployeeID = 1009,FirstName = "Amit",LastName = "Mistry",Title = "Associate",DOB = DateTime.Parse("8/12/1992"),DOJ = DateTime.Parse("12/3/2014"),City = "Chennai"},
            new Employee() {EmployeeID = 1010,FirstName = "Sumit",LastName = "Shah",Title = "Manager",DOB = DateTime.Parse("4/12/1991"),DOJ = DateTime.Parse("1/2/2016"),City = "Pune"},
        };
        public static void DisplayAll()
        {
            var displayallemployee = (from s in empList select s);
            Console.WriteLine("Details of all Employees = ");
            foreach (var s in displayallemployee)
            {
                Console.WriteLine(s.EmployeeID + "" + s.FirstName + "" + s.LastName + "" + s.Title + "" + s.DOB + "" + s.DOJ + "" + s.City);
            }
        }
        public static void Notmumbai()
        {
            var NotMumbailist = (from s in empList where s.City != "Mumbai" select s);
            Console.WriteLine("\nDetails of Employees whose location is not mumbai = ");
            foreach (var s in NotMumbailist)
            {
                Console.WriteLine(s.EmployeeID + "" + s.FirstName + "" + s.LastName + "" + s.Title + "" + s.DOB + "" + s.DOJ + "" + s.City);
            }
        }
        public static void TitleAssesstemt()
        {
            var TitleAssesstemtlist = (from s in empList where s.Title == "AsstManager" select s);
            Console.WriteLine("\nDetails of Employees whose title is AsstManager = ");
            foreach (var s in TitleAssesstemtlist)
            {
                Console.WriteLine(s.EmployeeID + "" + s.FirstName + "" + s.LastName + "" + s.Title + "" + s.DOB + "" + s.DOJ + "" + s.City);
            }
        }
        public static void LastNameS()
        {
            var LastNameSlist = (from s in empList where s.LastName.StartsWith("S") select s);
            Console.WriteLine("\nDetails Employees whose last name start with S = ");
            foreach (var s in LastNameSlist)
            {
                Console.WriteLine(s.EmployeeID + "" + s.FirstName + "" + s.LastName + "" + s.Title + "" + s.DOB + "" + s.DOJ + "" + s.City);
            }
        }
        public static void JoinedDate()
        {
            var JoinedDatelist = from s in empList where s.DOJ < DateTime.Parse("1/1/2015") select s;
            Console.WriteLine("\nDetails of employees who have joined before 1/1/2015 = ");
            foreach (var s in JoinedDatelist)
            {
                Console.WriteLine(s.EmployeeID + "" + s.FirstName + "" + s.LastName + "" + s.Title + "" + s.DOB + "" + s.DOJ + "" + s.City);
            }
        }
        public static void BirthDate()
        {
            var BirthDateemp = from s in empList where s.DOB > DateTime.Parse("1/1/1990") select s;
            Console.WriteLine("\nDetails of employees whose date of birth after 1/1/1990 = ");
            foreach (var s in BirthDateemp)
            {
                Console.WriteLine(s.EmployeeID + "" + s.FirstName + "" + s.LastName + "" + s.Title + "" + s.DOB + "" + s.DOJ + "" + s.City);
            }
        }
        public static void TitleCnstAsot()
        {
            var TitleCnstAsotlist = from s in empList where (s.Title == "Consultant" || s.Title == "Associate") select s;
            Console.WriteLine("\nAll the Employees whose designation is Consultant And Associate = ");
            foreach (var s in TitleCnstAsotlist)
            {
                Console.WriteLine(s.EmployeeID + "" + s.FirstName + "" + s.LastName + "" + s.Title + "" + s.DOB + "" + s.DOJ + "" + s.City);
            }
        }
        public static void Countemp()
        {
            //var Countemplist = (from s in empList select s).Count();
            var Countemplist = empList.Count();
            Console.WriteLine("\nTotal no. of Employee = {0}", Countemplist);
        }
        public static void BelongChennai()
        {
            var BelongChennaian = (from s in empList where s.City == "Chennai" select s).Count();
            Console.WriteLine("\nTotal no. of Employee belonging to Chennai = {0}", BelongChennaian);
        }
        public static void HighestId()
        {
            var HighestempId = (from s in empList select s.EmployeeID).Max();
            Console.WriteLine("\nHighest Employee ID = {0}", HighestempId);
        }
        public static void JoinedNum()
        {
            var JoinedempNum = (from s in empList where s.DOJ > DateTime.Parse("1/1/2015") select s).Count();
            Console.WriteLine("\nNumber of Employees Joined after 1/1/2015 = {0}", JoinedempNum);
        }
        public static void NotAssociate()
        {
            var NotAssociateNum = (from s in empList where s.Title != "Associate" select s).Count();
            Console.WriteLine("\nNumber of Employees who is not Associate = {0}", NotAssociateNum);
        }

        static void Main(String[] args)
        {
            DisplayAll();
            Notmumbai();
            TitleAssesstemt();
            LastNameS();
            JoinedDate();
            BirthDate();
            TitleCnstAsot();
            Countemp();
            BelongChennai();
            HighestId();
            JoinedNum();
            NotAssociate();
            Console.ReadKey();
        }
    }
}